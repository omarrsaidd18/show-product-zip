# Student Product Website

## Technologies
- HTML5
- CSS3
- JavaScript
- Bootstrap 5 (local copy, works offline)

## How to run
1. Extract the ZIP file.
2. Open the project folder.
3. Open `index.html` in a browser.

## Structure
- كل الملفات في فولدر واحد (index.html جنب الباقي)
- `css/style.css` - a few small styles (page background, image height, 3-line description)
- `js/script.js` - product array and functions
- `images/` - local product images (replace them with your own using the same file names if you want)
- `lib/bootstrap/` - local Bootstrap CSS and JS

## JavaScript
- `products` array holds name, category, description, price and image
- `createProductCard()` builds one Bootstrap card
- `showProducts()` fills the grid when the button is clicked
- `showProductDetails()` fills and opens the Bootstrap modal
