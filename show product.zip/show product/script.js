const products = [
  {
    name: "Essence Mascara Lash Princess",
    category: "beauty",
    description: "The Essence Mascara Lash Princess is a popular mascara known for its volumizing and lengthening effects. Achieve dramatic lashes with this long-lasting and cruelty-free formula.",
    price: 9.99,
    image: "mascara.jpg"
  },
  {
    name: "Eyeshadow Palette with Mirror",
    category: "beauty",
    description: "The Eyeshadow Palette with Mirror offers a versatile range of eyeshadow shades for creating stunning eye looks. With a built-in mirror, it's convenient for on-the-go makeup application.",
    price: 19.99,
    image: "eyeshadow.jpg"
  },
  {
    name: "Powder Canister",
    category: "beauty",
    description: "The Powder Canister is a finely milled setting powder designed to set makeup and control shine. With a lightweight and translucent formula, it provides a smooth and matte finish.",
    price: 14.99,
    image: "powder.jpg"
  },
  {
    name: "Red Lipstick",
    category: "beauty",
    description: "The Red Lipstick is a classic and bold choice for adding a pop of color to your lips. With a creamy and pigmented formula, it provides a vibrant and long-lasting finish.",
    price: 12.99,
    image: "lipstick.jpg"
  }
];

const showButton = document.getElementById("showButton");
const productList = document.getElementById("productList");
const modalTitle = document.getElementById("modalTitle");
const modalBody = document.getElementById("modalBody");
const productModal = new bootstrap.Modal(document.getElementById("productModal"));

function createProductCard(product) {
  const col = document.createElement("div");
  col.className = "col-12 col-sm-6 col-lg-3";
  col.innerHTML = `
    <div class="card h-100 shadow-sm">
      <div class="card-body d-flex flex-column">
        <img src="${product.image}" class="product-img w-100 mb-3" alt="${product.name}">
        <h5 class="card-title fw-semibold">${product.name}</h5>
        <h6 class="card-subtitle mb-3 text-muted fw-normal">${product.category}</h6>
        <p class="card-text product-description">${product.description}</p>
        <p class="fs-5 fw-semibold text-success mt-auto">$${product.price}</p>
        <button class="btn btn-primary w-100">View Product</button>
      </div>
    </div>`;

  col.querySelector("button").addEventListener("click", function () {
    showProductDetails(product);
  });
  return col;
}

function showProducts() {
  productList.innerHTML = "";
  products.forEach(function (product) {
    productList.appendChild(createProductCard(product));
  });
}

function showProductDetails(product) {
  modalTitle.textContent = product.name;
  modalBody.innerHTML = `
    <img src="${product.image}" class="img-fluid mb-3" alt="${product.name}">
    <p>${product.description}</p>
    <p class="mb-1 text-muted">${product.category}</p>
    <p class="fs-5 fw-semibold text-success mb-0">$${product.price}</p>`;
  productModal.show();
}

showButton.addEventListener("click", showProducts);
